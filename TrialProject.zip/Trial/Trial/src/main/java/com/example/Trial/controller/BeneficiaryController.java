package com.example.Trial.controller;

import com.example.Trial.model.Beneficiary;
import com.example.Trial.model.Transaction;
import com.example.Trial.service.BeneficiaryService;
import com.opencsv.exceptions.CsvException;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.io.IOException;
import java.util.List;

@RestController
public class BeneficiaryController {

    private final BeneficiaryService beneficiaryService;

    public BeneficiaryController(BeneficiaryService beneficiaryService) {
        this.beneficiaryService = beneficiaryService;
    }

    @GetMapping("/beneficiaries")
    public List<Beneficiary> getAllBeneficiaries() throws IOException, CsvException {
        return beneficiaryService.getAllBeneficiaries();
    }

    @GetMapping("/beneficiaries/{id}")
    public Beneficiary getBeneficiary(@PathVariable Long id) throws IOException, CsvException {
        return beneficiaryService.getAllBeneficiaries().stream()
                .filter(beneficiary -> beneficiary.getBeneficiaryId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // Endpoint to get all transactions of a beneficiary
    @GetMapping("/api/beneficiaries/{beneficiaryId}/transactions")
    public List<Transaction> getBeneficiaryTransactions(@PathVariable Long beneficiaryId) {
        return beneficiaryService.getTransactionsForBeneficiary(beneficiaryId);
    }

    // Endpoint to get the largest withdrawal for a beneficiary in the last month
    @GetMapping("/api/{beneficiaryId}/largestWithdrawal")
    public Transaction getLargestWithdrawalForBeneficiary(@PathVariable Long beneficiaryId) {
        return beneficiaryService.getLargestWithdrawalInLastMonth(beneficiaryId);
    }
}
