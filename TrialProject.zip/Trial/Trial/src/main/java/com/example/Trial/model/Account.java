package com.example.Trial.model;

import lombok.Data;

@Data
public class Account {
    private Long accountId;
    private Long beneficiaryId;

    public Account(Long accountId, Long beneficiaryId) {
        this.accountId = accountId;
        this.beneficiaryId = beneficiaryId;
    }
    
    public Account() {
    }

    public Long getAccountId() {
        return accountId;
    }
    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }
    public Long getBeneficiaryId() {
        return beneficiaryId;
    }
    public void setBeneficiaryId(Long beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }
}
