package com.example.Trial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrialProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrialProjectApplication.class, args);
	}

}
