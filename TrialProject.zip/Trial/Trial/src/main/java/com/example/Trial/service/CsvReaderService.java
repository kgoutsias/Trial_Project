package com.example.Trial.service;

import com.example.Trial.model.Account;
import com.example.Trial.model.Transaction;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class CsvReaderService {
    public List<String[]> readCsv(String filePath) throws IOException, CsvException {
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            List<String[]> allData = reader.readAll();
            // Skip the first line (header)
            if (!allData.isEmpty()) {
                allData.remove(0);  // This removes the header row
            }

            return allData;  // Return the remaining data without the header
        }
    }

    public List<Account> readAccountsFromCsv() {
        List<Account> accounts = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader("C:/Users/kgoutsias/Downloads/Trial/Trial/src/main/resources/accounts.csv"))) {
            reader.readNext(); // Skip the header row
            String[] line;
            while ((line = reader.readNext()) != null) {
                Long accountId = Long.parseLong(line[0]);
                Long beneficiaryId = Long.parseLong(line[1]);
                accounts.add(new Account(accountId, beneficiaryId));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accounts;
    }

    public List<Transaction> readTransactionsFromCsv() {
        List<Transaction> transactions = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader("C:/Users/kgoutsias/Downloads/Trial/Trial/src/main/resources/transactions.csv"))) {
            reader.readNext(); // Skip the header row
            String[] line;
            while ((line = reader.readNext()) != null) {
                Long transactionId = Long.parseLong(line[0]);
                Long accountId = Long.parseLong(line[1]);
                double amount = Double.parseDouble(line[2]);
                String type = line[3];
                String date = line[4];
                transactions.add(new Transaction(transactionId, accountId, amount, type, date));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return transactions;
    }
}
