package com.example.Trial.controller;

import com.example.Trial.service.BeneficiaryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BalanceController {
    private final BeneficiaryService beneficiaryService;
    public BalanceController(BeneficiaryService beneficiaryService) {
        this.beneficiaryService = beneficiaryService;
    }

    @GetMapping("/api/beneficiaries/{beneficiaryId}/balance")
    public double getBeneficiaryTotalBalance(@PathVariable Long beneficiaryId) {
        return beneficiaryService.calculateTotalBalance(beneficiaryId);
    }
}
