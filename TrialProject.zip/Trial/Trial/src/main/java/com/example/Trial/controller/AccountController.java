package com.example.Trial.controller;

import com.example.Trial.model.Account;
import com.example.Trial.service.AccountService;
import com.opencsv.exceptions.CsvException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
public class AccountController {
    private final AccountService accountService;
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/accounts")
    public List<Account> getAllAccounts() throws IOException, CsvException {
        return accountService.getAllAccounts();
    }

    @GetMapping("/beneficiaries/{id}/accounts")
    public List<Account> getAccountsByBeneficiary(@PathVariable Long id) throws IOException, CsvException {
        return accountService.getAllAccounts().stream()
                .filter(account -> account.getBeneficiaryId().equals(id))
                .toList();
    }
}
