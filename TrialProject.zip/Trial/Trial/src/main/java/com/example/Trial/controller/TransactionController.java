package com.example.Trial.controller;

import com.example.Trial.model.Transaction;
import com.example.Trial.service.TransactionService;
import com.opencsv.exceptions.CsvException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
public class TransactionController {

    private final TransactionService transactionService;
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @GetMapping("/transactions")
    public List<Transaction> getAllTransactions() throws IOException, CsvException {
        return transactionService.getAllTransactions();
    }

    @GetMapping("/beneficiaries/{id}/transactions")
    public List<Transaction> getTransactionsByBeneficiary(@PathVariable Long id) throws IOException, CsvException {
        return transactionService.getAllTransactions().stream()
                .filter(transaction -> transaction.getAccountId().equals(id)) // use the account to the benef
                .toList();
    }
}
