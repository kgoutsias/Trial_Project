package com.example.Trial.service;

import com.example.Trial.model.Transaction;
import com.opencsv.exceptions.CsvException;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service

public class TransactionService {
    private final CsvReaderService csvReaderService;

    public TransactionService(CsvReaderService csvReaderService) {
        this.csvReaderService = csvReaderService;
    }

    public List<Transaction> getAllTransactions() throws IOException, CsvException {
        List<String[]> transactionsData = csvReaderService.readCsv("C:/Users/kgoutsias/Downloads/Trial/Trial/src/main/resources/transactions.csv");
        List<Transaction> transactions = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");
        for (String[] row : transactionsData) {
            Transaction transaction = new Transaction();
            transaction.setTransactionId(Long.parseLong(row[0]));
            transaction.setAccountId(Long.parseLong(row[1]));
            transaction.setAmount(Double.parseDouble(row[2]));
            transaction.setType(row[3]);
            transaction.setDate(row[4]);
            transactions.add(transaction);
        }
        return transactions;
    }
}
