package com.example.Trial.service;

import com.example.Trial.model.Account;
import com.opencsv.exceptions.CsvException;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class AccountService {
    private final CsvReaderService csvReaderService;

    public AccountService(CsvReaderService csvReaderService) {
        this.csvReaderService = csvReaderService;
    }

    public List<Account> getAllAccounts() throws IOException, CsvException {
        List<String[]> accountsData = csvReaderService.readCsv("C:/Users/kgoutsias/Downloads/Trial/Trial/src/main/resources/accounts.csv");
        List<Account> accounts = new ArrayList<>();
        for (String[] row : accountsData) {
            Account account = new Account();
            account.setAccountId(Long.parseLong(row[0]));
            account.setBeneficiaryId(Long.parseLong(row[1]));
            accounts.add(account);
        }
        return accounts;
    }
}
