package com.example.Trial.service;

import com.example.Trial.model.Account;
import com.example.Trial.model.Beneficiary;
import com.example.Trial.model.Transaction;
import org.springframework.stereotype.Service;
import com.opencsv.exceptions.CsvException;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service

public class BeneficiaryService {
    private final CsvReaderService csvReaderService;
    private final List<Account> accounts;
    private final List<Transaction> transactions;

    public BeneficiaryService(CsvReaderService csvReaderService) {
        this.csvReaderService = csvReaderService;
        this.accounts = csvReaderService.readAccountsFromCsv();
        this.transactions = csvReaderService.readTransactionsFromCsv();
    }

    public List<Beneficiary> getAllBeneficiaries() throws IOException, CsvException {
        List<String[]> beneficiariesData = csvReaderService.readCsv("C:/Users/kgoutsias/Downloads/Trial/Trial/src/main/resources/beneficiaries.csv");
        List<Beneficiary> beneficiaries = new ArrayList<>();
        for (String[] row : beneficiariesData) {
            Beneficiary beneficiary = new Beneficiary();
            beneficiary.setBeneficiaryId(Long.parseLong(row[0]));
            beneficiary.setFirstName(row[1]);
            beneficiary.setLastName(row[2]);
            beneficiaries.add(beneficiary);
        }
        return beneficiaries;
    }

    /**
     * Get all transactions for a specific beneficiary
     * @param beneficiaryId
     * @return
     */
    public List<Transaction> getTransactionsForBeneficiary(Long beneficiaryId) {
        // Find the accounts for the given beneficiary
        List<Account> beneficiaryAccounts = accounts.stream()
                .filter(account -> account.getBeneficiaryId().equals(beneficiaryId))
                .collect(Collectors.toList());

        // Find the transactions for those accounts
        return transactions.stream()
                .filter(transaction -> beneficiaryAccounts.stream()
                        .anyMatch(account -> account.getAccountId().equals(transaction.getAccountId())))
                .collect(Collectors.toList());
    }

    /**
     * Calculate total balance for a beneficiary
     * @param beneficiaryId
     * @return
     */
    public double calculateTotalBalance(Long beneficiaryId) {
        // Get the accounts belonging to the beneficiary
        List<Account> beneficiaryAccounts = accounts.stream()
                .filter(account -> account.getBeneficiaryId().equals(beneficiaryId))
                .collect(Collectors.toList());

        double totalBalance = 0;

        // For each account, calculate the balance
        for (Account account : beneficiaryAccounts) {
            double accountBalance = 0;

            // Get all transactions for this account
            List<Transaction> accountTransactions = transactions.stream()
                    .filter(transaction -> transaction.getAccountId().equals(account.getAccountId()))
                    .collect(Collectors.toList());

            // Calculate the balance based on transactions
            for (Transaction transaction : accountTransactions) {
                if ("deposit".equalsIgnoreCase(transaction.getType())) {
                    accountBalance += transaction.getAmount(); // Add deposits
                } else if ("withdrawal".equalsIgnoreCase(transaction.getType())) {
                    accountBalance -= transaction.getAmount(); // Subtract withdrawals
                }
            }
            totalBalance += accountBalance;
        }

        return totalBalance;
    }
    

    /**
     * Get the largest withdrawal for a specific beneficiary in the last month
     * We filter transactions for type withdrawal.
     * We further filter them by checking if the transaction date is within the last month.
     * We use max to find the largest withdrawal amount.
     * @param beneficiaryId
     * @return
     */
    public Transaction getLargestWithdrawalInLastMonth(Long beneficiaryId) {
        // Find the accounts for the given beneficiary
        List<Account> beneficiaryAccounts = accounts.stream()
                .filter(account -> account.getBeneficiaryId().equals(beneficiaryId))
                .collect(Collectors.toList());

        // Get current date and date of the previous month
        LocalDate now = LocalDate.now();
        LocalDate oneMonthAgo = now.minusMonths(1);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");

        // Find withdrawals from the last month for those accounts
        return transactions.stream()
                .filter(transaction -> transaction.getType().equalsIgnoreCase("withdrawal"))
                .filter(transaction -> beneficiaryAccounts.stream()
                        .anyMatch(account -> account.getAccountId().equals(transaction.getAccountId())))
                .filter(transaction -> {
                    LocalDate transactionDate = LocalDate.parse(transaction.getDate(), formatter);
                    return transactionDate.isAfter(oneMonthAgo) && transactionDate.isBefore(now);
                })
                // Find the largest withdrawal
                .max(Comparator.comparingDouble(Transaction::getAmount))
                .orElse(null);  // Return null if no withdrawal found
    }
    
}
